package cas.lab6.wt;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ MoneyTestAdd.class, MoneyTestEquals.class, MoneyTest.class })
public class AllMoneyTests {

}
